/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 *
 * @author ASUS
 */
public class TUBESFIX {
    
    static List<String> toArray(String word) {
        List<String> list = new ArrayList<>();
        char x;
        String text = "";
        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) != ' ') {
//            if (word.charAt(i) != ' ' && word.charAt(i) != '(' && word.charAt(i) != ')') {
                text += word.charAt(i);
            }
            if ((word.charAt(i) == ' ' || i+1 == word.length()) && ((text != "") || word.charAt(i) != ' ')) {
                list.add(text);
                text = "";
            }
            if (word.charAt(i) == '(' && word.charAt(i+1) != ' '){
                list.add(text);
                text = "";
            }
            if (i+1 != word.length()){
                if (word.charAt(i) != ' ' && word.charAt(i+1) == ')'){
                    list.add(text);
                    text = "";
                }
            }
        }
        
        return list;
    }
    
    static boolean Operand(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'p' || x.charAt(i) == 'q' || x.charAt(i) == 'r' || x.charAt(i) == 's') {
                        state = "Q1";
                    } else {
                        state = "Q2";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'p' || x.charAt(i) == 'q' || x.charAt(i) == 'r' || x.charAt(i) == 's') {
                        state = "Q2";
                    }
                    break;
            }
            i++;
        }
        if (state == "Q1") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean Not(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'n') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'o') {
                        state = "Q2";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) == 't') {
                        state = "Q3";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q3":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'n' || x.charAt(i) == 'o' || x.charAt(i) == 't') {
                        state = "Q4";
                    }
                    break;   
            }
            i++;
        }
        if (state == "Q3") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean And(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'a') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'n') {
                        state = "Q2";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) == 'd') {
                        state = "Q3";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q3":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'a' || x.charAt(i) == 'n' || x.charAt(i) == 'd') {
                        state = "Q4";
                    }
                    break;   
            }
            i++;
        }
        if (state == "Q3") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean Or(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'o') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'r') {
                        state = "Q2";
                    } else {
                        state = "Q3";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) != ' ') {
                        state = "Q3";
                    }
                    break; 
            }
            i++;
        }
        if (state == "Q2") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean Xor(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'x') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'o') {
                        state = "Q2";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) == 'r') {
                        state = "Q3";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q3":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'x' || x.charAt(i) == 'o' || x.charAt(i) == 'r') {
                        state = "Q4";
                    }
                    break;   
            }
            i++;
        }
        if (state == "Q3") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean If(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'i') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'f') {
                        state = "Q2";
                    } else {
                        state = "Q3";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) != ' ') {
                        state = "Q3";
                    }
                    break; 
            }
            i++;
        }
        if (state == "Q2") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean Then(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 't') {
                        state = "Q1";
                    } else {
                        state = "Q5";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'h') {
                        state = "Q2";
                    } else {
                        state = "Q5";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) == 'e') {
                        state = "Q3";
                    } else {
                        state = "Q5";
                    }
                    break;
                case "Q3":
                    if (x.charAt(i) == 'n') {
                        state = "Q4";
                    } else {
                        state = "Q5";
                    }
                    break;
                case "Q4":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'f' || x.charAt(i) == 'f' || x.charAt(i) == 'f') {
                        state = "Q5";
                    }
                    break;   
            }
            i++;
        }
        if (state == "Q4") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean Iff(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == 'i') {
                        state = "Q1";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) == 'f') {
                        state = "Q2";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q2":
                    if (x.charAt(i) == 'f') {
                        state = "Q3";
                    } else {
                        state = "Q4";
                    }
                    break;
                case "Q3":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == 'f' || x.charAt(i) == 'f' || x.charAt(i) == 'f') {
                        state = "Q4";
                    }
                    break;   
            }
            i++;
        }
        if (state == "Q3") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean openParenthesis(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == '(') {
                        state = "Q1";
                    } else {
                        state = "Q2";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == '(') {
                        state = "Q2";
                    }
                    
            }
            i++;
        }
        if (state == "Q1") {
            return true;
        } else {
            return false;
        }
    }
    
    static boolean closeParenthesis(String x) {
        String state = "Q0";
        int i = 0;
        while (i < x.length()) {
            switch(state) {
                case "Q0":
                    if (x.charAt(i) == ')') {
                        state = "Q1";
                    } else {
                        state = "Q2";
                    }
                    break;
                case "Q1":
                    if (x.charAt(i) != ' ') {
//                    if (x.charAt(i) == ')') {
                        state = "Q2";
                    }
                    
            }
            i++;
        }
        if (state == "Q1") {
            return true;
        } else {
            return false;
        }
    }
    
    static void Parser(List<String> token, String status) {
        Stack<String> stack = new Stack<>();
        stack.add("#");
        stack.add("S");
        int i = 0;
        boolean a = true;
        while(i < token.size() && stack.peek() != "#" && status == "true" && a) {
            System.out.print(token.get(i) + " : ");
            switch (stack.peek()) {
                case "S" : 
                    if (token.get(i) == "1") {
                        if (i + 1 != token.size()) {
                            if (token.get(i + 1) == "3") {
                                stack.pop();
                                stack.push("S");
                                stack.push("3");
                                stack.push("1");
                            } else if (token.get(i + 1) == "4") {
                                stack.pop();
                                stack.push("S");
                                stack.push("4");
                                stack.push("1");
                            } else if (token.get(i + 1) == "5") {
                                stack.pop();
                                stack.push("S");
                                stack.push("5");
                                stack.push("1");
                            } else if (token.get(i + 1) == "8") {
                                stack.pop();
                                stack.push("S");
                                stack.push("8");
                                stack.push("1");
                            } else if (token.get(i + 1) != "1") {
                                stack.pop();
                                stack.push("1");
                            } else {
                                a = false;
                            }
                        } else {
                            stack.pop();
                            stack.push("1");
                        }
                    } else if (token.get(i) == "2") {
                        stack.pop();
                        stack.push("S");
                        stack.push("2");
                    } else if (token.get(i) == "6") {
                        stack.pop();
                        stack.push("S");
                        stack.push("7");
                        stack.push("S");
                        stack.push("6");
                    } else if (token.get(i) == "9") {
                        stack.pop();
                        stack.push("10");
                        stack.push("S");
                        stack.push("9");
                    } else {
                        a = false;
                    }
                    break;
                case "1" :
                    stack.pop();
                    i++;
                    break;
                case "2" :
                    stack.pop();
                    i++;
                    break;
                case "3" :
                    stack.pop();
                    i++;
                    break;
                case "4" :
                    stack.pop();
                    i++;
                    break;
                case "5" :
                    stack.pop();
                    i++;
                    break;
                case "6" :
                    stack.pop();
                    i++;
                    break;
                case "7" :
                    stack.pop();
                    i++;
                    break;
                case "8" :
                    stack.pop();
                    i++;
                    break;
                case "9" :
                    stack.pop();
                    i++;
                    break;
                case "10" :
                    stack.pop();
                    i++;
                    break;
                    
            }
            System.out.println(stack);
        }
        if (stack.peek() == "#") {
            stack.pop();
            System.out.println("Valid");
        } else {
            System.out.println("Invalid");
        }
    }
    
    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String a = br.readLine();
        List<String> word = toArray(a);
        List<String> token = new ArrayList<>();
        System.out.println("Output : " + word);
        for (int i = 0; i < word.size(); i++) {
//            System.out.print(word.get(i) + " | ");
            if (Operand(word.get(i))) {
                token.add("1");
            } else if (Not(word.get(i))) {
                token.add("2");
            } else if (And(word.get(i))) {
                token.add("3");
            } else if (Or(word.get(i))) {
                token.add("4");
            } else if (Xor(word.get(i))) {
                token.add("5");
            } else if (If(word.get(i))) {
                token.add("6");
            } else if (Then(word.get(i))) {
                token.add("7");
            } else if (Iff(word.get(i))) {
                token.add("8");
            } else if (openParenthesis(word.get(i))) {
                token.add("9");
            } else if (closeParenthesis(word.get(i))) {
                token.add("10");
            } else {
                token.add("Error");
                break;
            }
        }
        System.out.println("Output (Lexical Code) : " + token);
        int y = 0;
        for (int x = 0; x < token.size(); x++) {
            if (token.get(x) == "Error") {
                y = x;
            }
        }
        Parser(token, (token.get(y) != "Error" ? "true" : "false"));
    }
       
}